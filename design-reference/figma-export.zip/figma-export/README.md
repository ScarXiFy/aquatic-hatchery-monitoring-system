
  # Aquatic Hatchery Dashboard UI

  This is a code bundle for Aquatic Hatchery Dashboard UI. The original project is available at https://www.figma.com/design/Gfhi76GfCYQFcPyKrKWa3o/Aquatic-Hatchery-Dashboard-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  