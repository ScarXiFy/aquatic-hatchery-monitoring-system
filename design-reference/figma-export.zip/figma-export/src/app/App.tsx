import { useState } from 'react';
import { Dashboard } from './components/Dashboard';
import { GraphView } from './components/GraphView';

export default function App() {
  const [currentPage, setCurrentPage] = useState<'home' | 'graph'>('home');

  return (
    <div className="size-full">
      {currentPage === 'home' ? (
        <Dashboard onNavigate={setCurrentPage} />
      ) : (
        <GraphView onNavigate={setCurrentPage} />
      )}
    </div>
  );
}