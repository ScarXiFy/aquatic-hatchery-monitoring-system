import { RadialBarChart, RadialBar, PolarAngleAxis } from 'recharts';

interface CircularGaugeProps {
  value: number;
  min: number;
  max: number;
  label: string;
  unit: string;
  safeMin: number;
  safeMax: number;
  warningMin: number;
  warningMax: number;
  status?: 'optimal' | 'warning' | 'critical';
}

export function CircularGauge({
  value,
  min,
  max,
  label,
  unit,
  safeMin,
  safeMax,
  warningMin,
  warningMax,
  status
}: CircularGaugeProps) {
  const percentage = ((value - min) / (max - min)) * 100;

  const getColor = () => {
    if (value >= safeMin && value <= safeMax) return '#10b981';
    if (value >= warningMin && value <= warningMax) return '#fbbf24';
    return '#ef4444';
  };

  const color = getColor();
  const data = [{ value: percentage, fill: color }];

  const getStatusBadge = () => {
    const badges = {
      optimal: { text: 'Optimal', color: 'bg-green-500/20 border-green-500/40 text-green-400' },
      warning: { text: 'Warning', color: 'bg-yellow-500/20 border-yellow-500/40 text-yellow-400' },
      critical: { text: 'Critical', color: 'bg-red-500/20 border-red-500/40 text-red-400' }
    };
    return status ? badges[status] : null;
  };

  const statusBadge = getStatusBadge();

  return (
    <div className="flex flex-col items-center">
      <div className="relative" style={{ filter: `drop-shadow(0 0 10px ${color}40)` }}>
        <RadialBarChart
          width={160}
          height={160}
          innerRadius="65%"
          outerRadius="90%"
          data={data}
          startAngle={180}
          endAngle={0}
        >
          <PolarAngleAxis type="number" domain={[0, 100]} angleAxisId={0} tick={false} />
          <RadialBar dataKey="value" cornerRadius={10} />
        </RadialBarChart>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <div className="text-3xl font-bold text-white tracking-tight">{value.toFixed(1)}</div>
          <div className="text-sm text-gray-300 font-semibold mt-0.5">{unit}</div>
        </div>
      </div>
      <div className="text-white font-semibold mt-3 text-sm">{label}</div>
      {statusBadge && (
        <div className={`mt-1.5 px-2.5 py-0.5 rounded-md border text-xs font-bold ${statusBadge.color}`}>
          {statusBadge.text}
        </div>
      )}
    </div>
  );
}
