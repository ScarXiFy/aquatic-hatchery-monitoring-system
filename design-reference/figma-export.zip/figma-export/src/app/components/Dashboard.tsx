import { useState } from 'react';
import { CircularGauge } from './CircularGauge';
import { TrendIndicator } from './TrendIndicator';
import { Bell, User, Wifi, WifiOff, Activity, TrendingUp, TrendingDown, Minus } from 'lucide-react';

interface DashboardProps {
  onNavigate: (page: 'home' | 'graph') => void;
}

export function Dashboard({ onNavigate }: DashboardProps) {
  const [temperature, setTemperature] = useState(26);
  const [dissolvedOxygen, setDissolvedOxygen] = useState(7.2);
  const [ledLevel, setLedLevel] = useState(3);
  const [waterSourceOpen, setWaterSourceOpen] = useState(true);
  const [drainageOpen, setDrainageOpen] = useState(false);

  const [thresholds, setThresholds] = useState([
    { parameter: 'Salinity', min: 30.0, max: 35.0, unit: 'g/L', status: 'warning' as const },
    { parameter: 'pH', min: 7.5, max: 8.5, unit: '', status: 'optimal' as const }
  ]);

  const updateThreshold = (index: number, field: 'min' | 'max', value: number) => {
    const updated = [...thresholds];
    updated[index][field] = value;
    setThresholds(updated);
  };

  const getLuxValue = (level: number): number => {
    const luxMap: { [key: number]: number } = {
      0: 0,
      1: 100,
      2: 500,
      3: 1000,
      4: 3000,
      5: 5000
    };
    return luxMap[level] || 0;
  };

  const sensorData = {
    temperature: { value: 26.5, min: 15, max: 35, safeMin: 22, safeMax: 28, warningMin: 20, warningMax: 30 },
    dissolvedOxygen: { value: 7.2, min: 0, max: 15, safeMin: 6, safeMax: 9, warningMin: 5, warningMax: 10 },
    salinity: { value: 32.1, min: 0, max: 50, safeMin: 30, safeMax: 35, warningMin: 28, warningMax: 37 },
    pH: { value: 7.8, min: 0, max: 14, safeMin: 7.5, safeMax: 8.5, warningMin: 7.0, warningMax: 9.0 }
  };

  const trends = {
    temperature: { min: 24.2, current: 26.5, max: 28.1 },
    DO: { min: 6.8, current: 7.2, max: 8.4 },
    salinity: { min: 31.5, current: 32.1, max: 33.2 },
    pH: { min: 7.6, current: 7.8, max: 8.1 }
  };


  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-teal-900 to-gray-900">
      {/* Top Navigation */}
      <nav className="bg-gray-900/90 backdrop-blur-lg border-b border-teal-800/40 shadow-lg">
        <div className="px-6 py-3.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <h1 className="text-xl font-bold text-white tracking-wide">
                Aquatic Hatchery <span className="text-teal-400">Monitoring System</span>
              </h1>
            </div>

            <div className="flex items-center space-x-10">
              <button
                onClick={() => onNavigate('home')}
                className="relative text-white hover:text-teal-300 transition-colors pb-1 text-sm font-medium"
              >
                Home
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-teal-400 to-cyan-400 rounded-full" />
              </button>
              <button
                onClick={() => onNavigate('graph')}
                className="text-gray-400 hover:text-white transition-colors text-sm font-medium"
              >
                View Graph
              </button>
            </div>

            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-1.5 px-2.5 py-1 bg-green-500/20 border border-green-500/30 rounded-lg">
                <Activity className="w-3.5 h-3.5 text-green-400" />
                <span className="text-green-400 text-xs font-medium">Optimal</span>
              </div>
              <div className="flex items-center space-x-1.5 px-2.5 py-1 bg-cyan-500/20 border border-cyan-500/30 rounded-lg">
                <Wifi className="w-3.5 h-3.5 text-cyan-400" />
                <span className="text-cyan-300 text-xs font-medium">RPi Connected</span>
              </div>
              <span className="text-gray-400 text-xs font-medium">Apr 21, 2026 | 14:32</span>
              <button className="relative p-1.5 hover:bg-gray-800 rounded-lg transition-colors">
                <Bell className="w-4 h-4 text-gray-400 hover:text-white" />
              </button>
              <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center cursor-pointer shadow-lg hover:shadow-purple-500/50 transition-shadow">
                <User className="w-4 h-4 text-white" />
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Dashboard */}
      <div className="p-5 grid grid-cols-12 gap-5">

        {/* Live Sensor Readings */}
        <div className="col-span-8">
          <div className="bg-gray-800/50 backdrop-blur-lg rounded-2xl border border-teal-700/40 p-5 shadow-2xl">
            <h2 className="text-xl font-bold text-white mb-5 tracking-wide">Live Sensor Readings</h2>
            <div className="grid grid-cols-4 gap-5">
              <CircularGauge
                {...sensorData.temperature}
                label="Temperature"
                unit="°C"
                status="optimal"
              />
              <CircularGauge
                {...sensorData.dissolvedOxygen}
                label="Dissolved Oxygen"
                unit="mg/L"
                status="optimal"
              />
              <CircularGauge
                {...sensorData.salinity}
                label="Salinity"
                unit="g/L"
                status="warning"
              />
              <CircularGauge
                {...sensorData.pH}
                label="pH Level"
                unit=""
                status="optimal"
              />
            </div>
          </div>

          {/* System Controls */}
          <div className="grid grid-cols-2 gap-5 mt-5">
            <div className="bg-gray-800/50 backdrop-blur-lg rounded-2xl border border-teal-700/40 p-5 shadow-2xl">
              <h3 className="text-lg font-bold text-white mb-4 tracking-wide">System Controls</h3>
              <div className="space-y-5">
                <div>
                  <div className="flex justify-between items-center text-white mb-2">
                    <span className="font-medium text-sm">Temperature</span>
                    <div className="px-2.5 py-1 bg-teal-500/20 border border-teal-400/30 rounded-lg">
                      <span className="text-teal-300 font-bold text-sm">{temperature}°C</span>
                    </div>
                  </div>
                  <div className="relative">
                    <input
                      type="range"
                      min="15"
                      max="35"
                      value={temperature}
                      onChange={(e) => setTemperature(Number(e.target.value))}
                      className="w-full h-2.5 bg-gray-700 rounded-full appearance-none cursor-pointer accent-teal-500"
                      style={{
                        background: `linear-gradient(to right, rgb(20 184 166) 0%, rgb(20 184 166) ${((temperature - 15) / 20) * 100}%, rgb(55 65 81) ${((temperature - 15) / 20) * 100}%, rgb(55 65 81) 100%)`
                      }}
                    />
                  </div>
                  <div className="flex justify-between text-xs text-gray-400 mt-1.5 font-medium">
                    <span>15°C</span>
                    <span>35°C</span>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between items-center text-white mb-2">
                    <span className="font-medium text-sm">Dissolved Oxygen</span>
                    <div className="px-2.5 py-1 bg-teal-500/20 border border-teal-400/30 rounded-lg">
                      <span className="text-teal-300 font-bold text-sm">{dissolvedOxygen.toFixed(1)} mg/L</span>
                    </div>
                  </div>
                  <div className="relative">
                    <input
                      type="range"
                      min="0"
                      max="15"
                      step="0.1"
                      value={dissolvedOxygen}
                      onChange={(e) => setDissolvedOxygen(Number(e.target.value))}
                      className="w-full h-2.5 bg-gray-700 rounded-full appearance-none cursor-pointer accent-teal-500"
                      style={{
                        background: `linear-gradient(to right, rgb(20 184 166) 0%, rgb(20 184 166) ${(dissolvedOxygen / 15) * 100}%, rgb(55 65 81) ${(dissolvedOxygen / 15) * 100}%, rgb(55 65 81) 100%)`
                      }}
                    />
                  </div>
                  <div className="flex justify-between text-xs text-gray-400 mt-1.5 font-medium">
                    <span>0 mg/L</span>
                    <span>15 mg/L</span>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between items-center text-white mb-2">
                    <span className="font-medium text-sm">LED Light Intensity</span>
                    <div className="px-2.5 py-1 bg-teal-500/20 border border-teal-400/30 rounded-lg">
                      <span className="text-teal-300 font-bold text-sm">{getLuxValue(ledLevel)} lx</span>
                    </div>
                  </div>
                  <div className="relative">
                    <input
                      type="range"
                      min="0"
                      max="5"
                      value={ledLevel}
                      onChange={(e) => setLedLevel(Number(e.target.value))}
                      className="w-full h-2.5 bg-gray-700 rounded-full appearance-none cursor-pointer accent-teal-500"
                      style={{
                        background: `linear-gradient(to right, rgb(20 184 166) 0%, rgb(20 184 166) ${(ledLevel / 5) * 100}%, rgb(55 65 81) ${(ledLevel / 5) * 100}%, rgb(55 65 81) 100%)`
                      }}
                    />
                  </div>
                  <div className="flex justify-between text-xs text-gray-400 mt-1.5 font-medium">
                    <span>0 lx</span>
                    <span>5000 lx</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Control Valves */}
            <div className="bg-gray-800/50 backdrop-blur-lg rounded-2xl border border-teal-700/40 p-5 shadow-2xl">
              <h3 className="text-lg font-bold text-white mb-4 tracking-wide">Control Valves</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-gray-900/40 rounded-lg border border-gray-700/50">
                  <span className="text-white font-semibold text-sm">Water Source Pipe</span>
                  <button
                    onClick={() => setWaterSourceOpen(!waterSourceOpen)}
                    className={`flex items-center space-x-1.5 px-4 py-1.5 rounded-lg font-bold text-sm transition-all ${
                      waterSourceOpen
                        ? 'bg-green-500/90 text-white shadow-lg shadow-green-500/40 hover:bg-green-500'
                        : 'bg-red-500/90 text-white shadow-lg shadow-red-500/40 hover:bg-red-500'
                    }`}
                  >
                    <div className={`w-2 h-2 rounded-full bg-white animate-pulse`} />
                    <span>{waterSourceOpen ? 'OPEN' : 'CLOSED'}</span>
                  </button>
                </div>
                <div className="flex items-center justify-between p-3 bg-gray-900/40 rounded-lg border border-gray-700/50">
                  <span className="text-white font-semibold text-sm">Drainage Pipe</span>
                  <button
                    onClick={() => setDrainageOpen(!drainageOpen)}
                    className={`flex items-center space-x-1.5 px-4 py-1.5 rounded-lg font-bold text-sm transition-all ${
                      drainageOpen
                        ? 'bg-green-500/90 text-white shadow-lg shadow-green-500/40 hover:bg-green-500'
                        : 'bg-red-500/90 text-white shadow-lg shadow-red-500/40 hover:bg-red-500'
                    }`}
                  >
                    <div className={`w-2 h-2 rounded-full bg-white animate-pulse`} />
                    <span>{drainageOpen ? 'OPEN' : 'CLOSED'}</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Side Panel */}
        <div className="col-span-4 space-y-5">
          {/* Trends Panel */}
          <div className="bg-gray-800/50 backdrop-blur-lg rounded-2xl border border-teal-700/40 p-5 shadow-2xl">
            <h2 className="text-xl font-bold text-white mb-5 tracking-wide">Trends (Last 24h)</h2>
            <div className="space-y-4">
              <TrendIndicator
                label="Temperature"
                {...trends.temperature}
                unit="°C"
                trend="increasing"
              />
              <TrendIndicator
                label="DO"
                {...trends.DO}
                unit="mg/L"
                trend="stable"
              />
              <TrendIndicator
                label="Salinity"
                {...trends.salinity}
                unit="g/L"
                trend="decreasing"
              />
              <TrendIndicator
                label="pH"
                {...trends.pH}
                unit=""
                trend="stable"
              />
            </div>
          </div>

          {/* Thresholds */}
          <div className="bg-gray-800/50 backdrop-blur-lg rounded-2xl border border-teal-700/40 p-5 shadow-2xl">
            <h3 className="text-lg font-bold text-white mb-4 tracking-wide">Thresholds</h3>
            <div>
              <table className="w-full table-fixed">
                <thead>
                  <tr className="border-b border-gray-700/60">
                    <th className="text-left text-gray-400 py-2 px-2 font-semibold text-xs w-[22%]">Parameter</th>
                    <th className="text-left text-gray-400 py-2 px-1 font-semibold text-xs w-[18%]">Min</th>
                    <th className="text-left text-gray-400 py-2 px-1 font-semibold text-xs w-[18%]">Max</th>
                    <th className="text-left text-gray-400 py-2 px-1 font-semibold text-xs w-[18%]">Unit</th>
                    <th className="text-left text-gray-400 py-2 px-2 font-semibold text-xs w-[24%]">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {thresholds.map((threshold, index) => (
                    <tr key={threshold.parameter} className="border-b border-gray-800/60">
                      <td className="text-white py-2.5 px-2 font-medium text-sm">{threshold.parameter}</td>
                      <td className="py-2.5 px-1">
                        <input
                          type="number"
                          step="0.1"
                          value={threshold.min}
                          onChange={(e) => updateThreshold(index, 'min', parseFloat(e.target.value) || 0)}
                          className="w-full bg-gray-700/60 text-teal-300 px-2 py-1 rounded-lg border border-teal-600/40 focus:outline-none focus:border-teal-500 focus:ring-1 focus:ring-teal-500/30 font-medium text-xs"
                        />
                      </td>
                      <td className="py-2.5 px-1">
                        <input
                          type="number"
                          step="0.1"
                          value={threshold.max}
                          onChange={(e) => updateThreshold(index, 'max', parseFloat(e.target.value) || 0)}
                          className="w-full bg-gray-700/60 text-teal-300 px-2 py-1 rounded-lg border border-teal-600/40 focus:outline-none focus:border-teal-500 focus:ring-1 focus:ring-teal-500/30 font-medium text-xs"
                        />
                      </td>
                      <td className="text-gray-400 py-2.5 px-1 font-medium text-xs">{threshold.unit}</td>
                      <td className="py-2.5 px-2">
                        {threshold.status === 'optimal' && (
                          <span className="inline-flex items-center px-2 py-0.5 bg-green-500/20 border border-green-500/40 rounded-md text-green-400 text-xs font-bold">
                            Optimal
                          </span>
                        )}
                        {threshold.status === 'warning' && (
                          <span className="inline-flex items-center px-2 py-0.5 bg-yellow-500/20 border border-yellow-500/40 rounded-md text-yellow-400 text-xs font-bold">
                            Warning
                          </span>
                        )}
                        {threshold.status === 'critical' && (
                          <span className="inline-flex items-center px-2 py-0.5 bg-red-500/20 border border-red-500/40 rounded-md text-red-400 text-xs font-bold">
                            Critical
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
