import { useState } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceArea } from 'recharts';
import { Bell, User, Wifi, Activity, Maximize2, Download } from 'lucide-react';

interface GraphViewProps {
  onNavigate: (page: 'home' | 'graph') => void;
}

export function GraphView({ onNavigate }: GraphViewProps) {
  const [timeRange, setTimeRange] = useState<'24H' | '7D'>('24H');

  const generateData = () => {
    const pointsMap = { '24H': 24, '7D': 7 };
    const points = pointsMap[timeRange];
    return Array.from({ length: points }, (_, i) => ({
      time: timeRange === '7D' ? `Day ${i + 1}` : `${i}:00`,
      temperature: 25 + Math.random() * 4,
      pH: 7.5 + Math.random() * 1,
      dissolvedOxygen: 6.5 + Math.random() * 2,
      salinity: 31 + Math.random() * 3
    }));
  };

  const data = generateData();

  const getStats = (dataKey: string) => {
    const values = data.map(d => d[dataKey as keyof typeof d] as number);
    return {
      current: values[values.length - 1].toFixed(1),
      min: Math.min(...values).toFixed(1),
      max: Math.max(...values).toFixed(1),
      avg: (values.reduce((a, b) => a + b, 0) / values.length).toFixed(1)
    };
  };

  const ChartCard = ({
    title,
    dataKey,
    color,
    unit,
    thresholds
  }: {
    title: string;
    dataKey: string;
    color: string;
    unit: string;
    thresholds?: { safe: [number, number]; warning: [number, number] };
  }) => {
    const stats = getStats(dataKey);

    return (
      <div className="bg-gray-800/30 backdrop-blur-sm rounded-xl p-4 shadow-xl border border-gray-700/50">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-base font-bold text-white tracking-wide">{title}</h3>
          <div className="flex items-center space-x-2">
            <button className="p-1 hover:bg-gray-700/50 rounded transition-colors">
              <Maximize2 className="w-3.5 h-3.5 text-gray-400 hover:text-white" />
            </button>
            <button className="p-1 hover:bg-gray-700/50 rounded transition-colors">
              <Download className="w-3.5 h-3.5 text-gray-400 hover:text-white" />
            </button>
          </div>
        </div>

        <div className="flex items-center space-x-3 mb-3">
          <div className="flex items-center space-x-1.5">
            <span className="text-xs text-gray-400">Current:</span>
            <span className="text-sm font-bold text-teal-300">{stats.current} {unit}</span>
          </div>
          <div className="flex items-center space-x-1.5">
            <span className="text-xs text-gray-400">Min:</span>
            <span className="text-xs font-semibold text-gray-300">{stats.min}</span>
          </div>
          <div className="flex items-center space-x-1.5">
            <span className="text-xs text-gray-400">Max:</span>
            <span className="text-xs font-semibold text-gray-300">{stats.max}</span>
          </div>
        </div>

        <ResponsiveContainer width="100%" height={180}>
          <LineChart data={data}>
            {thresholds && (
              <>
                <ReferenceArea y1={thresholds.safe[0]} y2={thresholds.safe[1]} fill="#10b981" fillOpacity={0.1} />
                <ReferenceArea y1={thresholds.warning[0]} y2={thresholds.safe[0]} fill="#fbbf24" fillOpacity={0.08} />
                <ReferenceArea y1={thresholds.safe[1]} y2={thresholds.warning[1]} fill="#fbbf24" fillOpacity={0.08} />
              </>
            )}
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" opacity={0.3} />
            <XAxis dataKey="time" stroke="#9ca3af" style={{ fontSize: '11px', fontWeight: 500 }} />
            <YAxis stroke="#9ca3af" style={{ fontSize: '11px', fontWeight: 500 }} />
            <Tooltip
              contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151', borderRadius: '8px', padding: '8px' }}
              labelStyle={{ color: '#fff', fontWeight: 'bold', fontSize: '12px' }}
              itemStyle={{ color: '#fff', fontSize: '12px' }}
              formatter={(value: number) => [`${value.toFixed(1)} ${unit}`, title]}
            />
            <Line type="monotone" dataKey={dataKey} stroke={color} strokeWidth={3} dot={{ r: 3, strokeWidth: 2, fill: color }} activeDot={{ r: 5 }} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-teal-900 to-gray-900">
      {/* Top Navigation */}
      <nav className="bg-gray-900/90 backdrop-blur-lg border-b border-teal-800/40 shadow-lg">
        <div className="px-6 py-3.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <h1 className="text-xl font-bold text-white tracking-wide">
                Aquatic Hatchery <span className="text-teal-400">Monitoring System</span>
              </h1>
            </div>

            <div className="flex items-center space-x-10">
              <button
                onClick={() => onNavigate('home')}
                className="text-gray-400 hover:text-white transition-colors text-sm font-medium"
              >
                Home
              </button>
              <button
                onClick={() => onNavigate('graph')}
                className="relative text-white hover:text-teal-300 transition-colors pb-1 text-sm font-medium"
              >
                View Graph
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-teal-400 to-cyan-400 rounded-full" />
              </button>
            </div>

            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-1.5 px-2.5 py-1 bg-green-500/20 border border-green-500/30 rounded-lg">
                <Activity className="w-3.5 h-3.5 text-green-400" />
                <span className="text-green-400 text-xs font-medium">Optimal</span>
              </div>
              <div className="flex items-center space-x-1.5 px-2.5 py-1 bg-cyan-500/20 border border-cyan-500/30 rounded-lg">
                <Wifi className="w-3.5 h-3.5 text-cyan-400" />
                <span className="text-cyan-300 text-xs font-medium">RPi Connected</span>
              </div>
              <span className="text-gray-400 text-xs font-medium">Apr 21, 2026 | 14:32</span>
              <button className="relative p-1.5 hover:bg-gray-800 rounded-lg transition-colors">
                <Bell className="w-4 h-4 text-gray-400 hover:text-white" />
              </button>
              <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center cursor-pointer shadow-lg hover:shadow-purple-500/50 transition-shadow">
                <User className="w-4 h-4 text-white" />
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Graph Content */}
      <div className="p-5">
        <div className="mb-4 flex items-center justify-between">
          <h1 className="text-2xl font-bold text-white tracking-wide">Data Visualization</h1>
          <div className="flex space-x-2">
            {(['24H', '7D'] as const).map((range) => (
              <button
                key={range}
                onClick={() => setTimeRange(range)}
                className={`px-4 py-1.5 rounded-lg font-bold text-sm transition-all ${
                  timeRange === range
                    ? 'bg-teal-500 text-white shadow-lg shadow-teal-500/40'
                    : 'bg-gray-800/70 text-gray-300 hover:bg-gray-700 border border-gray-700'
                }`}
              >
                {range === '24H' ? 'Day' : 'Week'}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <ChartCard
            title="Temperature"
            dataKey="temperature"
            color="#06b6d4"
            unit="°C"
            thresholds={{ safe: [22, 28], warning: [18, 32] }}
          />
          <ChartCard
            title="pH Level"
            dataKey="pH"
            color="#8b5cf6"
            unit=""
            thresholds={{ safe: [7.5, 8.5], warning: [7.0, 9.0] }}
          />
          <ChartCard
            title="Dissolved Oxygen"
            dataKey="dissolvedOxygen"
            color="#10b981"
            unit="mg/L"
            thresholds={{ safe: [6, 9], warning: [5, 10] }}
          />
          <ChartCard
            title="Salinity"
            dataKey="salinity"
            color="#f59e0b"
            unit="g/L"
            thresholds={{ safe: [30, 35], warning: [28, 37] }}
          />
        </div>
      </div>
    </div>
  );
}
