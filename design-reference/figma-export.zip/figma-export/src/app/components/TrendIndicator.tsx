import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

interface TrendIndicatorProps {
  label: string;
  min: number;
  current: number;
  max: number;
  unit: string;
  trend?: 'increasing' | 'decreasing' | 'stable';
}

export function TrendIndicator({ label, min, current, max, unit, trend }: TrendIndicatorProps) {
  const range = max - min;
  const currentPosition = ((current - min) / range) * 100;

  const getTrendIcon = () => {
    if (trend === 'increasing') return <TrendingUp className="w-4 h-4 text-green-400" />;
    if (trend === 'decreasing') return <TrendingDown className="w-4 h-4 text-red-400" />;
    return <Minus className="w-4 h-4 text-gray-400" />;
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-1.5">
        <div className="flex items-center space-x-1.5">
          <span className="text-xs font-semibold text-gray-200">{label}</span>
          {trend && getTrendIcon()}
        </div>
        <span className="text-base font-bold text-teal-300">{current.toFixed(1)} <span className="text-xs font-medium text-gray-400">{unit}</span></span>
      </div>
      <div className="relative h-2.5 bg-gray-700/60 rounded-full border border-gray-600/40">
        <div
          className="absolute h-2.5 bg-gradient-to-r from-teal-500 to-cyan-400 rounded-full shadow-lg"
          style={{ width: `${currentPosition}%`, boxShadow: '0 0 6px rgba(20, 184, 166, 0.5)' }}
        />
        <div
          className="absolute w-3.5 h-3.5 bg-white rounded-full shadow-lg border-2 border-teal-400 -top-0.5"
          style={{ left: `calc(${currentPosition}% - 7px)` }}
        />
      </div>
      <div className="flex justify-between text-xs text-gray-500 mt-1.5 font-medium">
        <span>{min.toFixed(1)}</span>
        <span>{max.toFixed(1)}</span>
      </div>
    </div>
  );
}
